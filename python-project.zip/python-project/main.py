
def chatbot():
    print("Welcome to My Basic Chatbot!")
    print("You can chat with me.")
    print("Type 'bye' to exit.")

    while True:
        user = input("You: ").lower().strip()

        if user == "hello" or user == "hi":
            print("Bot: Hi! Welcome to my chatbot.")

        elif user == "how are you":
            print("Bot: I'm fine, thanks! How can I help you?")

        elif user == "what is your name":
            print("Bot: I am a Basic Python Chatbot.")

        elif user == "help":
            print("Bot: You can say hello, ask how I am, or ask my name.")

        elif user == "bye":
            print("Bot: Goodbye! Have a nice day!")
            break

        else:
            print("Bot: Sorry, I don't understand. Please try again.")


chatbot()
